#!/usr/bin/env python

from projectserver.srv import getwaypoint,getwaypointResponse
import rospy


Color = [2,1,1,3,3]
X =  [2,-1.5,-2.8,-2.7,-0.4]
Y = [2,1,1.8,3.2,5.7]

def handle_Final_ints(req):
    global i
    global X
    global Y
    if req.firstwp == True :
        i = 0 
        success = True
        waypointx = X[i]
        waypointy = Y[i]
        return getwaypointResponse(success,waypointx,waypointy)
    else:
        if req.symboldetected == True:
            if req.symbolcolor == Color[i] and req.symbolpositionx == X[i] and req.symbolpositiony == Y[i]:
                success = True
		i = (i+1)%5           
            else:
                success = False
            waypointx = X[i]
            waypointy = Y[i]    
            return getwaypointResponse(success,waypointx,waypointy)
def Final_ints_server():
    global i 
    i = 0
    rospy.init_node('Final_ints_server')
    s = rospy.Service('Final_ints', getwaypoint, handle_Final_ints)
    print "Ready to go."
    rospy.spin()

if __name__ == "__main__":
    Final_ints_server()
